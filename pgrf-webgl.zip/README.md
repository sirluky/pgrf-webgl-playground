# MY PGRF PLAIN WEBGL PLAYGROUND

Muj playground na pripravu projektu do PGRF (počítačové grafiky).
Rozhodl jsem se že se hecnu a budu místo kodění v Javě na (OpenGl) dělat to ve WebGL a to i přesto že je to víc challenging (protože Webgl nemá defaultně nijak řešenou fixní pipeline).

To jsem zvědavej jak to dopadne...
